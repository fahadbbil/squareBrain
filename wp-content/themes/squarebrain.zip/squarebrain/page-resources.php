<?php
/*
	Template Name: Resources
*/
get_header(); 

get_template_part( 'template-parts/content', 'resources' ); 

get_footer();