	<section class="resource-block">
        <div class="container">
            <h1 class="text-uppercase text-center">Additional resources</h1>
            <?php get_template_part( 'template-parts/content', 'resourcesFeatures' ); ?>
        </div>
    </section>