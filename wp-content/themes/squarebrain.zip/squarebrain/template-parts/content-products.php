	<section class="products-block">
        <div class="container">
            <h1 class="text-uppercase">
                our squarekits
            </h1>
            <?php
            echo do_shortcode( '[products limit = "40" columns = "4"]
            ', false );?>
		</div>
	</section>