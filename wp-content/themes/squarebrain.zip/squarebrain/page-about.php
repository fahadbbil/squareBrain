<?php
/*
	Template Name: About
*/
get_header(); 

get_template_part( 'template-parts/content', 'about' ); 

get_footer();