<?php
/*
	Template Name: Products
*/
get_header(); 

get_template_part( 'template-parts/content', 'products' ); 

get_footer();